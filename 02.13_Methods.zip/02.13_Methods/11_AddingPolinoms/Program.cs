﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Problem 11. Adding polynomials
// Write a method that adds two polynomials.
// Represent them as arrays of their coefficients.

namespace _11_AddingPolinoms
{
    class Program
    {
       

        static void Main(string[] args)
        {

        }
    }
}
