﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14_QuickSort
{
    class Problem14
    {
        static void Main(string[] args)
        {
            // Input and filling the string
            Console.Write("Enteer array size: ");
            int arrSize = int.Parse(Console.ReadLine());
            int[] inputArr = new int[arrSize];

            for (int i = 0; i < inputArr.Length; i++)
            {
                inputArr[i] = int.Parse(Console.ReadLine());
            }

            // WTF


        }
        // Try to create a method
        static void Algoritm(int[] inputArr, int arrSize)
        {

        }
    }
}
